# apps/meters/views.py
from rest_framework import viewsets, filters, status
from rest_framework.decorators import action
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend

from core.mixins import TenantQuerySetMixin
from core.permissions import IsManager, IsFieldWorker
from core.pagination import StandardResultsPagination
from .models import WaterMeter, MeterReading
from .serializers import (
    WaterMeterSerializer, WaterMeterListSerializer,
    MeterReadingSerializer,
)
from .filters import WaterMeterFilter, MeterReadingFilter


class WaterMeterViewSet(TenantQuerySetMixin, viewsets.ModelViewSet):
    """
    CRUD de medidores. Leituristas só podem listar/ver detalhes.
    """
    queryset = (
        WaterMeter.objects
        .select_related('address', 'address__customer')
        .prefetch_related('readings')
        .order_by('serial_number')
    )
    pagination_class = StandardResultsPagination
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_class = WaterMeterFilter
    search_fields = ['serial_number']
    ordering_fields = ['serial_number', 'installation_date', 'status']

    def get_permissions(self):
        # Leituristas podem apenas listar e ver detalhes
        if self.action in ['list', 'retrieve']:
            return [IsFieldWorker()]
        return [IsManager()]

    def get_serializer_class(self):
        if self.action == 'list':
            return WaterMeterListSerializer
        return WaterMeterSerializer

    @action(detail=True, methods=['get', 'post'], url_path='readings')
    def readings(self, request, pk=None):
        meter = self.get_object()

        if request.method == 'GET':
            qs = meter.readings.all()
            filterset = MeterReadingFilter(request.GET, queryset=qs)
            page = self.paginate_queryset(filterset.qs)
            serializer = MeterReadingSerializer(page, many=True)
            return self.get_paginated_response(serializer.data)

        # POST — registrar nova leitura
        data = request.data.copy()
        data['meter'] = meter.pk
        serializer = MeterReadingSerializer(
            data=data,
            context={'request': request}
        )
        serializer.is_valid(raise_exception=True)
        serializer.save(
            reader=request.user,
            company=meter.company,
        )
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=['post'])
    def set_maintenance(self, request, pk=None):
        meter = self.get_object()
        meter.status = 'MAINTENANCE'
        meter.save(update_fields=['status'])
        return Response({'status': 'medidor em manutenção'})
