# apps/meters/serializers.py
from rest_framework import serializers
from .models import WaterMeter, MeterReading


class MeterReadingSerializer(serializers.ModelSerializer):
    reader_name = serializers.SerializerMethodField()
    consumption_m3 = serializers.SerializerMethodField()

    class Meta:
        model = MeterReading
        fields = [
            'id', 'meter', 'reader', 'reader_name',
            'reading_value', 'reading_date',
            'consumption_m3', 'image_evidence',
            'created_at',
        ]
        read_only_fields = [
            'id', 'created_at', 'reader_name', 'consumption_m3'
        ]

    def get_reader_name(self, obj):
        return obj.reader.get_full_name() if obj.reader else None

    def get_consumption_m3(self, obj):
        """
        Diferença entre esta leitura e a anterior do mesmo medidor.
        Retorna None se for a primeira leitura.
        """
        prev = (
            MeterReading.objects
            .filter(meter=obj.meter, reading_date__lt=obj.reading_date)
            .order_by('-reading_date')
            .first()
        )
        if prev is None:
            return None
        return float(obj.reading_value - prev.reading_value)

    def validate_reading_value(self, value):
        if value < 0:
            raise serializers.ValidationError(
                "O valor de leitura não pode ser negativo."
            )
        # Garante que a nova leitura é maior que a última
        meter = self.initial_data.get('meter') or (
            self.instance.meter_id if self.instance else None
        )
        if meter:
            last = (
                MeterReading.objects
                .filter(meter_id=meter)
                .order_by('-reading_date')
                .first()
            )
            if last and value < last.reading_value:
                raise serializers.ValidationError(
                    f"Valor ({value}) menor que a última leitura "
                    f"({last.reading_value}). Verifique o medidor."
                )
        return value


class WaterMeterSerializer(serializers.ModelSerializer):
    address_detail = serializers.SerializerMethodField()
    last_reading = serializers.SerializerMethodField()

    class Meta:
        model = WaterMeter
        fields = [
            'id', 'serial_number', 'address', 'address_detail',
            'installation_date', 'status',
            'last_reading', 'created_at', 'updated_at',
        ]
        read_only_fields = [
            'id', 'created_at', 'updated_at',
            'address_detail', 'last_reading',
        ]

    def get_address_detail(self, obj):
        from customers.serializers import AddressSerializer
        return AddressSerializer(obj.address).data

    def get_last_reading(self, obj):
        last = obj.readings.first()  # já ordenado por -reading_date
        if last is None:
            return None
        return {
            'value': float(last.reading_value),
            'date': last.reading_date,
        }

    def validate_serial_number(self, value):
        qs = WaterMeter.objects.filter(serial_number=value)
        if self.instance:
            qs = qs.exclude(pk=self.instance.pk)
        if qs.exists():
            raise serializers.ValidationError(
                "Já existe um medidor com este número de série."
            )
        return value


class WaterMeterListSerializer(serializers.ModelSerializer):
    class Meta:
        model = WaterMeter
        fields = ['id', 'serial_number', 'status', 'installation_date']
