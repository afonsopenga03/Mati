# apps/payments/serializers.py
from rest_framework import serializers
from .models import Payment
from billing.models import Invoice


class PaymentSerializer(serializers.ModelSerializer):
    invoice_status = serializers.SerializerMethodField()

    class Meta:
        model = Payment
        fields = [
            'id', 'invoice', 'invoice_status',
            'payment_date', 'amount_paid',
            'method', 'transaction_id',
            'created_at',
        ]
        read_only_fields = [
            'id', 'payment_date', 'created_at', 'invoice_status'
        ]

    def get_invoice_status(self, obj):
        return obj.invoice.status

    def validate_invoice(self, invoice):
        # Evita pagamentos duplicados
        if hasattr(invoice, 'payment'):
            raise serializers.ValidationError(
                "Esta fatura já possui um pagamento registrado."
            )
        if invoice.status == 'CANCELLED':
            raise serializers.ValidationError(
                "Não é possível pagar uma fatura cancelada."
            )
        # Garante que a fatura é da mesma empresa
        request = self.context.get('request')
        if request and not request.user.is_superuser:
            if invoice.company != request.user.company:
                raise serializers.ValidationError(
                    "Esta fatura não pertence à sua empresa."
                )
        return invoice

    def validate_amount_paid(self, value):
        if value <= 0:
            raise serializers.ValidationError(
                "O valor pago deve ser maior que zero."
            )
        return value

    def create(self, validated_data):
        payment = super().create(validated_data)
        # Atualiza o status da fatura para PAID automaticamente
        payment.invoice.status = 'PAID'
        payment.invoice.save(update_fields=['status'])
        return payment
