# apps/payments/views.py
from rest_framework import viewsets, filters
from django_filters.rest_framework import DjangoFilterBackend

from core.mixins import TenantQuerySetMixin
from core.permissions import IsManager
from core.pagination import StandardResultsPagination
from .models import Payment
from .serializers import PaymentSerializer


class PaymentViewSet(TenantQuerySetMixin, viewsets.ModelViewSet):
    """
    Pagamentos são imutáveis após criação (sem PUT/PATCH/DELETE).
    """
    queryset = (
        Payment.objects
        .select_related('invoice', 'invoice__customer')
        .order_by('-payment_date')
    )
    serializer_class = PaymentSerializer
    permission_classes = [IsManager]
    pagination_class = StandardResultsPagination
    http_method_names = ['get', 'post', 'head', 'options']  # sem PUT/PATCH/DELETE
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_fields = ['method']
    ordering_fields = ['payment_date', 'amount_paid']
