from django.db import models
from core.models import TenantModel  # <-- ADICIONE ISSO

class Payment(TenantModel):
    invoice = models.OneToOneField('billing.Invoice', on_delete=models.PROTECT)
    payment_date = models.DateTimeField(auto_now_add=True)
    amount_paid = models.DecimalField(max_digits=12, decimal_places=2)
    method = models.CharField(max_length=50)
    transaction_id = models.CharField(max_length=255, unique=True)
