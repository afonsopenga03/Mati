from django.db import models

# Create your models here.
# apps/billing/models.py
from core.models import TenantModel

class TariffPlan(TenantModel):
    name = models.CharField(max_length=100)
    base_fee = models.DecimalField(max_digits=10, decimal_places=2) # Valor fixo
    cost_per_m3 = models.DecimalField(max_digits=10, decimal_places=2)

class Invoice(TenantModel):
    STATUS_CHOICES = (('PENDING', 'Pendente'), ('PAID', 'Pago'), ('OVERDUE', 'Atrasado'), ('CANCELLED', 'Cancelado'))

    customer = models.ForeignKey('customers.Customer', on_delete=models.PROTECT)
    due_date = models.DateField()
    total_amount = models.DecimalField(max_digits=12, decimal_places=2)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='PENDING')
    pdf_file = models.FileField(upload_to='invoices/', null=True, blank=True)

class InvoiceItem(TenantModel):
    invoice = models.ForeignKey(Invoice, on_delete=models.CASCADE, related_name='items')
    description = models.CharField(max_length=200)
    quantity = models.DecimalField(max_digits=10, decimal_places=2)
    unit_price = models.DecimalField(max_digits=10, decimal_places=2)
    subtotal = models.DecimalField(max_digits=12, decimal_places=2)
