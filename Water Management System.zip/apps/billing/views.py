# apps/billing/views.py
from rest_framework import viewsets, filters, status
from rest_framework.decorators import action
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend

from core.mixins import TenantQuerySetMixin
from core.permissions import IsManager, IsAdminUser
from core.pagination import StandardResultsPagination
from .models import TariffPlan, Invoice, InvoiceItem
from .serializers import (
    TariffPlanSerializer, InvoiceSerializer,
    InvoiceListSerializer, InvoiceCreateWithItemsSerializer,
    InvoiceItemSerializer,
)
from .filters import InvoiceFilter


class TariffPlanViewSet(TenantQuerySetMixin, viewsets.ModelViewSet):
    queryset = TariffPlan.objects.all().order_by('name')
    serializer_class = TariffPlanSerializer
    permission_classes = [IsManager]
    pagination_class = StandardResultsPagination
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['name']
    ordering_fields = ['name', 'base_fee', 'cost_per_m3']


class InvoiceViewSet(TenantQuerySetMixin, viewsets.ModelViewSet):
    queryset = (
        Invoice.objects
        .select_related('customer')
        .prefetch_related('items')
        .order_by('-due_date')
    )
    permission_classes = [IsManager]
    pagination_class = StandardResultsPagination
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_class = InvoiceFilter
    search_fields = ['customer__first_name', 'customer__last_name']
    ordering_fields = ['due_date', 'total_amount', 'status']

    def get_serializer_class(self):
        if self.action == 'list':
            return InvoiceListSerializer
        if self.action == 'create':
            return InvoiceCreateWithItemsSerializer
        return InvoiceSerializer

    @action(detail=True, methods=['post'])
    def mark_paid(self, request, pk=None):
        invoice = self.get_object()
        if invoice.status == 'PAID':
            return Response(
                {'error': 'Fatura já está paga.'},
                status=status.HTTP_400_BAD_REQUEST
            )
        invoice.status = 'PAID'
        invoice.save(update_fields=['status'])
        return Response({'status': 'fatura marcada como paga'})

    @action(detail=True, methods=['post'])
    def cancel(self, request, pk=None):
        invoice = self.get_object()
        if invoice.status in ('PAID', 'CANCELLED'):
            return Response(
                {'error': f'Não é possível cancelar uma fatura com status {invoice.status}.'},
                status=status.HTTP_400_BAD_REQUEST
            )
        invoice.status = 'CANCELLED'
        invoice.save(update_fields=['status'])
        return Response({'status': 'fatura cancelada'})

    @action(detail=False, methods=['get'])
    def summary(self, request):
        """Retorna totais agrupados por status para o dashboard."""
        from django.db.models import Sum, Count
        qs = self.get_queryset()
        data = (
            qs.values('status')
            .annotate(
                total_amount=Sum('total_amount'),
                count=Count('id'),
            )
            .order_by('status')
        )
        return Response(list(data))
