# apps/billing/serializers.py
from rest_framework import serializers
from .models import TariffPlan, Invoice, InvoiceItem


class TariffPlanSerializer(serializers.ModelSerializer):
    class Meta:
        model = TariffPlan
        fields = [
            'id', 'name', 'base_fee', 'cost_per_m3',
            'created_at', 'updated_at',
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']

    def validate_base_fee(self, value):
        if value < 0:
            raise serializers.ValidationError("Taxa base não pode ser negativa.")
        return value

    def validate_cost_per_m3(self, value):
        if value < 0:
            raise serializers.ValidationError("Custo por m³ não pode ser negativo.")
        return value


class InvoiceItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = InvoiceItem
        fields = [
            'id', 'description', 'quantity',
            'unit_price', 'subtotal',
        ]
        read_only_fields = ['id', 'subtotal']

    def validate(self, data):
        # Calcula subtotal automaticamente
        data['subtotal'] = data['quantity'] * data['unit_price']
        return data


class InvoiceSerializer(serializers.ModelSerializer):
    items = InvoiceItemSerializer(many=True, read_only=True)
    customer_name = serializers.SerializerMethodField()
    is_overdue = serializers.SerializerMethodField()

    class Meta:
        model = Invoice
        fields = [
            'id', 'customer', 'customer_name',
            'due_date', 'total_amount', 'status',
            'is_overdue', 'pdf_file',
            'items', 'created_at', 'updated_at',
        ]
        read_only_fields = [
            'id', 'created_at', 'updated_at',
            'customer_name', 'is_overdue',
        ]

    def get_customer_name(self, obj):
        return f"{obj.customer.first_name} {obj.customer.last_name}"

    def get_is_overdue(self, obj):
        from django.utils import timezone
        if obj.status in ('PAID', 'CANCELLED'):
            return False
        return obj.due_date < timezone.now().date()

    def validate_customer(self, customer):
        """Garante que o cliente pertence à mesma empresa."""
        request = self.context.get('request')
        if request and not request.user.is_superuser:
            if customer.company != request.user.company:
                raise serializers.ValidationError(
                    "Este cliente não pertence à sua empresa."
                )
        return customer


class InvoiceListSerializer(serializers.ModelSerializer):
    customer_name = serializers.SerializerMethodField()

    class Meta:
        model = Invoice
        fields = [
            'id', 'customer_name', 'due_date',
            'total_amount', 'status',
        ]

    def get_customer_name(self, obj):
        return f"{obj.customer.first_name} {obj.customer.last_name}"


class InvoiceCreateWithItemsSerializer(serializers.ModelSerializer):
    """Cria Invoice + InvoiceItems em uma única requisição."""
    items = InvoiceItemSerializer(many=True)

    class Meta:
        model = Invoice
        fields = [
            'customer', 'due_date', 'total_amount',
            'status', 'items',
        ]

    def create(self, validated_data):
        items_data = validated_data.pop('items')
        invoice = Invoice.objects.create(**validated_data)
        for item_data in items_data:
            InvoiceItem.objects.create(
                invoice=invoice,
                company=invoice.company,
                **item_data
            )
        return invoice
